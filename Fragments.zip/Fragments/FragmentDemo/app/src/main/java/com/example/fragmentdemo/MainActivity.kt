package com.example.fragmentdemo

import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val btReplace: Button =findViewById(R.id.btReplace)

        val firstFragmentManager: FragmentManager=supportFragmentManager
        val firstFragmentTransaction: FragmentTransaction= firstFragmentManager.beginTransaction()
        val firstFragment= FirstFragment()
        firstFragmentTransaction.add(R.id.frameLayout,firstFragment)
        firstFragmentTransaction.commit()

        btReplace.setOnClickListener {

            val secondFragment = SecondFragment()
            supportFragmentManager.beginTransaction()
                .replace(R.id.frameLayout, secondFragment)
                .commit()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}