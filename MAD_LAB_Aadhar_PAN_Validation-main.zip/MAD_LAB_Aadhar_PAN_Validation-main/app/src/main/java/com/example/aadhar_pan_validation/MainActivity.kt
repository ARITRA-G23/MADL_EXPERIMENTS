package com.example.aadhar_pan_validation

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val etPan = findViewById<EditText>(R.id.etPan)
        val etPincode = findViewById<EditText>(R.id.etPincode)
        val btnValidate = findViewById<Button>(R.id.btnValidate)

        btnValidate.setOnClickListener {

            val pan = etPan.text.toString().trim()
            val pincode = etPincode.text.toString().trim()

            // Rule i: Fields should not be empty
            if (pan.isEmpty() || pincode.isEmpty()) {
                Toast.makeText(this, "Fields should not be empty", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Rule ii: PAN validation (10-character alphanumeric)
            val panRegex = Regex("^[A-Za-z0-9]{10}$")
            if (!panRegex.matches(pan)) {
                Toast.makeText(this, "Invalid PAN Card Number", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Rule iii: Pincode validation (6-digit numeric)
            val pinRegex = Regex("^[0-9]{6}$")
            if (!pinRegex.matches(pincode)) {
                Toast.makeText(this, "Invalid Pincode", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // If all validations pass
            Toast.makeText(this, "Validation Successful", Toast.LENGTH_SHORT).show()
        }
    }

    }



