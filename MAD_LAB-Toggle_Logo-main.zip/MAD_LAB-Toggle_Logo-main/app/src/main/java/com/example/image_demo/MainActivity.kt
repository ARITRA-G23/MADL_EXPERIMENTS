package com.example.image_demo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.ImageView

class MainActivity : AppCompatActivity() {

    var imageOne: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)


        val myImage: ImageView = findViewById(R.id.imageView)
        val myButton: Button = findViewById(R.id.button)

        myButton.setOnClickListener {
            if (imageOne) {
                myImage.setImageResource(R.drawable.rec)
            } else {
                myImage.setImageResource(R.drawable.rsa)
            }
            // Toggle the boolean for the next click
            imageOne = !imageOne
        }
    }
}